'use strict';
const bestSellingProducts = require(`./bestSellingProducts`);

bestSellingProducts();